Arduino-only file extracted from the integration draft for rover_ws.
No GitHub files were changed.

IMPORTANT:
- The existing GitHub `robot_control.ino` is only a camera/two-sensor partial example, not a full motor firmware.
- This sketch preserves the current host protocol tokens rp/lp/gp/sp and telemetry p/m/g/er/el.
- The additional `cycle:1` token is additive. The current GitHub ROS2 rover_interface does not send this token, and the current GitHub joystick launch does not publish it. Therefore the manual full-cycle button will NOT trigger this firmware until a matching ROS-side sender is added. Existing joystick drive via joy_teleop / twist_mux remains on ROS side; this Arduino firmware accepts the wheel commands it gets and is not set to autonomous-only.
- This file keeps ULTRASONIC_AUTO_CYCLE_ENABLED=false by default. It does not automatically start the gripper cycle on proximity alone.
- Confirm pins, limit polarity/direction, encoder PPR, and actual gripper wiring before motor power is connected.
