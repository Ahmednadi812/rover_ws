# Rover integration patch (ROS 2 + Arduino Mega 2560)

This patch is based on the supplied 2026-10-16 Arduino firmware (`ENCODER_PPR=2200`, 20 ms wheel PID) and the current `rover_ws` source files. It intentionally does **not** import the old FreeRTOS `AUTOM` protocol and does not alter wheel PID constants, wheel-control period, command timeout, wheel PWM setup, encoder ISR structure, or existing token meanings.

## Repository finding: select the active Arduino sketch deliberately

The repository's current `src/rover_firmware/firmware/robot_control/robot_control.ino` is a camera-servo plus two-sensor fragment; its own header says it must be merged into a separate motor/gripper firmware. The old uploaded `FreeRTOS` sketch uses the incompatible `AUTOM` protocol and is not used here. The integrated candidate is added at `src/rover_firmware/firmware/minesweeper_rover_mega/minesweeper_rover_mega.ino` and preserves the supplied working `rp/lp/gp/sp` protocol and current PID values. Back up the exact sketch running on the robot before choosing which sketch to flash; compile only the intended folder.

## Files in this patch

- `src/rover_firmware/firmware/minesweeper_rover_mega/minesweeper_rover_mega.ino`: complete current sketch plus non-blocking ultrasonic measurement, a gripper-cycle state machine, a guarded `cycle:1,` one-shot command, `grip:reset,`, siren edge/hold policy, and additive status telemetry.
- `src/rover_firmware/src/rover_interface.cpp` and `include/rover_firmware/rover_interface.hpp`: preserves `rp/lp/gp/sp`, parses cumulative `er/el`, converts counts to joint positions and count deltas to velocity using monotonic host sample intervals, and emits only one cycle request frame per `/gripper/cycle_request` event.
- `src/rover_controller/src/gripper_cycle_joy_teleop.cpp`: rising-edge-only joystick button request.
- `src/rover_controller/CMakeLists.txt` and `launch/joystick_teleop.launch.py`: builds and launches the node with configurable `cycle_button_index`.
- `src/vision_pkg/vision_pkg/map_node.py`: accepts `/vision_cell` (and legacy `/current_cell`), maps rising sensor events only when a cell is fresh, shows proximity red and metal green, retains legacy Surface/Buried classifications.
- `src/rover_description/urdf/rover_ros2_control.xacro`: complete xacro with an `effective_counts_per_revolution` parameter, defaulting to 2200 until measured.
- `src/rover_map/launch/map_server.launch.py`: writes the annotated image to `~/.ros/annotated_map.png` instead of a developer-specific workspace path, and restores the expected `map -> odom` TF parent/child hierarchy using an identity initial alignment. This remains a fixed initial alignment, not a dynamic global-localization estimate.

## Protocol compatibility

At 115200 baud, regular frames remain newline-terminated comma tokens such as:

`rp1.00,lp1.00,gp0.00,sp0.00,`

Existing tokens are unchanged: `rp/rn` and `lp/ln` are wheel angular velocity (rad/s), `gp/gn` remains manual gripper velocity, `sp/sn` remains camera direction, and telemetry still includes `rp/lp,p0/p1,m0/m1,go/gc/gm,er:<count>,el:<count>,q...`.

New host-to-Arduino tokens: `cycle:1,` requests one cycle; `grip:reset,` clears a gripper fault only if lower limit is active and upper limit is inactive; `grip:recover_down,` is an explicit, conservative downward recovery request allowed only from FAULT when the lower limit is not active and both limits are not simultaneously active. New Arduino telemetry tokens: `us:<cm>`, `uv:0|1`, `cs:<state>`, `co:<outcome>`, `fr:<reason>`, `mg:0|1`, `si:0|1`. Old hosts may ignore unknown fields. The Arduino explicitly parses `cycle:1` before generic `r/l/g/s` token handling.

## Gripper states

- `BOOT`: outputs safe; no automatic homing move.
- `DOWN_READY`: lower limit active; ready to accept manual gp or cycle request; magnet policy is applied.
- `MAGNET_SETTLE`: ensure magnet on for 200 ms before lift.
- `MOVING_UP`: moves at separate conservative cycle PWM; stops immediately at top limit; timeout enters fault.
- `TOP_RELEASE`: lift stopped, magnet off, 750 ms dwell. Ultrasonic release verification is currently disabled by default until geometry is measured, so outcome explicitly remains `RELEASE_UNVERIFIED` rather than claiming success. When enabled, it requires three new valid readings at/above `US_RELEASE_CLEAR_DISTANCE_CM` or faults on timeout.
- `MOVING_DOWN`: moves to lower limit; stop at the limit; timeout enters fault.
- `FAULT`: lift output off; ordinary gp commands cannot defeat the fault or cycle ownership. `grip:reset` clears a fault only with lower active / upper inactive. For an operator-requested recovery from an unhomed/travel fault, publish `/gripper/recovery_down_request=true`; this permits only low-duty movement toward the lower limit with the same limit checks and timeout. If recovery times out or contradictory limits are active, output is shut off and the fault remains. Never use recovery with a jammed mechanism or unverified direction.

On power-on, `BOOT` accepts only a safe, unambiguous lower-limit-active state. If neither limit is active or both are active, firmware enters a fault instead of guessing a movement direction. Move the lift to the lower stop with power isolated, check switch wiring, then reboot.

## Topics

| Direction | Topic | Type | Meaning |
|---|---|---|---|
| ROS → hardware | `/gripper/cycle_request` | `std_msgs/msg/Bool` | `true` requests one full cycle; firmware rejects while busy/faulted |
| ROS → hardware | `/gripper/recovery_down_request` | `std_msgs/msg/Bool` | `true` requests bounded low-duty movement toward lower limit from FAULT |
| ROS → hardware | `/gripper/reset_request` | `std_msgs/msg/Bool` | `true` clears fault only if lower limit active / upper inactive |
| Arduino → ROS | `/proximity` | `std_msgs/msg/Bool` | aggregate proximity level; map records rising edges |
| Arduino → ROS | `/metal_detector` | `std_msgs/msg/Bool` | metal-detector level; map records rising edges |
| Arduino → ROS | `/proximity/sensor_1` … `/proximity/sensor_4` | `std_msgs/msg/Bool` | individual raw diagnostics from q1…q4; sampled every fifth telemetry line |
| Arduino → ROS | `/ultrasonic/distance` | `std_msgs/msg/Float32` | filtered distance in cm (latest transmitted value) |
| Arduino → ROS | `/ultrasonic/valid` | `std_msgs/msg/Bool` | latest range echo validity |
| Arduino → ROS | `/gripper/cycle_state` | `std_msgs/msg/String` | FSM state name |
| Arduino → ROS | `/gripper/cycle_outcome` | `std_msgs/msg/String` | cycle outcome/release verification result |
| Arduino → ROS | `/gripper/fault_reason` | `std_msgs/msg/String` | explicit gripper startup/travel/release fault reason |
| Arduino → ROS | `/magnet_state` | `std_msgs/msg/Bool` | commanded magnet-driver state |
| Arduino → ROS | `/siren_state` | `std_msgs/msg/Bool` | siren command state |
| Vision → map | `/vision_cell` or `/current_cell` | `std_msgs/msg/String` | grid cell like `G12` |
| Legacy classifier → map | `/mine_type` | `std_msgs/msg/String` | `Surface`, `Buried`, `Proximity`, or `Metal` |

## Important calibration and safety items before enabling the lift

1. **Pin conflict/wiring verification:** D43 trigger and D45 echo are imported from the older reference, not confirmed on the physical robot. Confirm these pins, sensor voltage levels, and common ground before connecting. HC-SR04 echo is typically 5 V; protect a Raspberry Pi GPIO if connecting there (this design connects it to Mega D45).
2. **Lift direction:** `LIFT_CLOSE_DIR_HIGH=true`, top=D51 and bottom=D53, active HIGH are inherited from supplied notes. Test direction with no load and wheels raised; do not assume the direction is correct.
3. **Limit wiring:** current sketch uses `INPUT` and expects external pull-downs so an unconnected input cannot float. Verify the actual pull-downs and confirm both-limit fault handling.
4. **Encoder scale:** firmware presently defines `ENCODER_PPR=2200` and attaches an interrupt on the rising edge of channel A only. The ROS interface defaults its effective counts/revolution to 2200; physically rotate each wheel exactly one revolution and measure `er/el` change to confirm this is the right *effective* count. Configure the confirmed value in the `effective_counts_per_revolution` parameter in the included xacro file. Left sign is negated so the joint angle follows the logical forward wheel direction.
5. **Proximity filtering:** the aggregate proximity state used by the siren/map requires two consecutive 20 ms samples; the `q1`…`q4` telemetry remains raw for diagnosis. Confirm the sensor polarity (`PROXIMITY_ACTIVE_STATE`) against the physical modules.
6. **Ultrasonic baseline:** the code learns an empty/down baseline from five valid filtered observations; it detects an object when the average changes by at least 3 cm for three samples, and can be set to require an additional proximity/metal event with `US_REQUIRE_DIGITAL_DETECTION_FOR_AUTO_CYCLE`. Automatic cycling is disabled by default (`ULTRASONIC_AUTO_CYCLE_ENABLED=false`) until the pin wiring, empty baseline, mine-present distance, and terrain/motion sensitivity have been bench-tested; enable it only after those tests. Missing echo is invalid and never treated as object detection.
7. **Release verification:** disabled by default because the actual sensor/mine/box geometry is unknown. Measure held and released distances first. If the sensor reliably reports a released/clear range, set `ULTRASONIC_RELEASE_VERIFY_ENABLED=true`, tune `US_RELEASE_CLEAR_DISTANCE_CM`, and test failure handling. Until then, the firmware reports `RELEASE_UNVERIFIED` rather than false success.
8. **Magnet driver:** D38 must drive a suitable MOSFET/relay driver, not the coil directly. Verify driver polarity/current and thermal behavior. Default policy is magnet on when down/ready and during lift, off at top release. This is a physical hazard if wiring is wrong.
9. **Siren:** D47 must use a rated external driver; never power the siren directly from an Arduino pin. The unknown buzzer remains disabled.
10. **Joystick button:** default cycle button index is 0, only a placeholder. Inspect `ros2 topic echo /joy` and choose a button not assigned to drive/open/close. The program checks `buttons.size()` and emits on rising edge only.
11. **TF/odometry ownership:** the patched real-robot launch sets `use_sim_time=false`, disables the simulation-only noisy odometry node, disables `simple_controller` TF publishing, and makes EKF consume `/rover_controller/odom`. Thus `simple_controller` publishes raw wheel odometry only and EKF is the sole publisher of `odom -> base_footprint_ekf`. A static identity transform connects `base_footprint_ekf -> base_footprint` for the URDF; Pure Pursuit and the zigzag planner use `base_footprint_ekf`. In standalone modes, do not enable competing broadcasters for the same child frame.

## Build and integration

1. Back up the working tree and firmware, then copy patch file paths over their matching repository paths.
2. Copy all patch files over the corresponding paths in the workspace. Review the xacro parameter and replace 2200 only after measuring the real count per wheel revolution.
3. Build ROS packages on the target ROS 2 environment:

```bash
cd ~/rover_ws
source /opt/ros/humble/setup.bash   # replace with the ROS distro installed on your Pi/laptop
colcon build --symlink-install --packages-up-to rover_bringup rover_firmware rover_controller vision_pkg rover_description rover_localization rover_map
source install/setup.bash
```

4. On a machine with Arduino CLI, compile/flash after checking board and port:

```bash
arduino-cli core list
arduino-cli compile --fqbn arduino:avr:mega:cpu=atmega2560 src/rover_firmware/firmware/minesweeper_rover_mega
# Flash only after reviewing all wiring and unplugging/isolating the lift as needed:
arduino-cli upload -p /dev/ttyUSB0 --fqbn arduino:avr:mega:cpu=atmega2560 src/rover_firmware/firmware/minesweeper_rover_mega
```

This is a local patch bundle; the GitHub default branch has not been changed. No Arduino CLI, ROS 2 installation, or `colcon` executable was present in the editing container, so hardware compilation/ROS build has **not** been claimed as successful. A host C++ syntax-only check with lightweight Arduino stubs, Python AST validation, and XML/YAML parsing were performed; these checks are not substitutes for `arduino-cli compile` and a ROS build.

## Staged test plan (do not skip)

1. **Source + communication only:** compile and flash with lift disconnected; verify serial monitor at 115200. Confirm continuous `rp/lp/gp/sp` command and telemetry tokens are unchanged; check `er/el` values change as wheels are turned by hand.
2. **ROS hardware interface:** build, launch with motors disabled, verify `/proximity`, `/metal_detector`, `/ultrasonic/*`, `/gripper/cycle_state`, `/gripper/cycle_outcome`, `/gripper/fault_reason`, `/gripper/recovery_down_request`, `/gripper/reset_request`, `/magnet_state`, `/siren_state`, and `/proximity/sensor_1` … `/proximity/sensor_4`. Confirm `/joint_states` changes `left_encoder_joint` / `right_encoder_joint` positions from `el/er`.
3. **Ultrasonic bench test:** lift disconnected; record `us` and `uv` for empty/down, target held, target removed, and no echo. Verify no echo sends `uv:0` and never requests a cycle. Tune threshold only from real measurements.
4. **Limit switch tests:** with lift power disconnected, manually actuate top and bottom. Confirm firmware startup faults when not safely down; confirm both active causes `FAULT`; confirm reset is ignored unless the system is in FAULT and the lower-only limit state is active.
5. **Lift no-load test:** wheels raised, magnet disconnected, limit switches and a battery cut-off reachable. With ROS active, send `ros2 topic pub --once /gripper/cycle_request std_msgs/msg/Bool "{data: true}"`; for direct serial bench tests send `cycle:1,`. verify magnet-settle → up → top stop → release → down → lower stop. Verify no automatic homing at startup, no endpoint overshoot, and `gp0.00` never interrupts the cycle. Check travel timeout by temporarily simulating a missing limit only under controlled conditions.
6. **Recovery test:** from a controlled FAULT state with verified limit wiring, send `ros2 topic pub --once /gripper/recovery_down_request std_msgs/msg/Bool "{data: true}"`; verify the lift moves only down and stops on the lower limit. Fault reset at the lower limit uses `/gripper/reset_request`.
7. **Magnet test:** verify external driver polarity, coil current, on-at-down, on-during-up, off-at-top, on-again-at-bottom. Start with a safe test object and monitor temperature/current.
8. **Release verification:** only after calibration, turn `ULTRASONIC_RELEASE_VERIFY_ENABLED` on, validate the clear-distance criterion, and verify an unconfirmed release faults at top instead of driving down or reporting success.
9. **Joystick:** view `/joy`, choose the dedicated button index, hold the button and confirm a single `true` request. Release and press again; active-cycle presses must not restart/reverse the lift.
10. **Map integration:** publish fresh `/vision_cell` e.g. `G12`, trigger `/proximity` and verify red, trigger `/metal_detector` and verify green. Sustain each high and confirm only one edge update. Publish stale/missing cell and confirm no location is created. Metal wins if both detections identify the same cell.
11. **Odometry + TF:** compare a hand-measured one-wheel revolution against joint radian change; correct the effective counts parameter from physical measurement. Run only one odometry/TF publisher per launch mode. Check `ros2 topic info /rover_controller/odom`, `ros2 topic info /rover_controller/odom_noisy`, and `ros2 run tf2_ros tf2_echo odom base_footprint`.
12. **IMU input:** the EKF configuration subscribes to `imu_ekf`, produced by republishing `/imu/out`. The existing driver is commented out in `real_robot.launch.py`; verify `ros2 topic echo /imu/out` is active from your currently launched driver. If it is absent, enable the correct driver or disable the `imu0` input in EKF YAML before relying on localization.
13. **Autonomous trial: only after all previous checks, use a low speed, open test area, dead-man/operator beside emergency battery disconnect. Trigger proximity/metal while zigzag navigation runs and verify navigation doesn't stop solely due to detection or gripper cycle.
