#include "rover_controller/noisy_controller.hpp"
#include <tf2/LinearMath/Quaternion.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iterator>
#include <random>
#include <string>

using std::placeholders::_1;

NoisyController::NoisyController(const std::string& name)
  : Node(name), prev_time_(get_clock()->now())
{
    declare_parameter("wheel_radius", 0.105);
    declare_parameter("wheel_separation", 0.5967);
    declare_parameter("publish_tf", false);
    wheel_radius_ = get_parameter("wheel_radius").as_double();
    wheel_separation_ = get_parameter("wheel_separation").as_double();
    publish_tf_ = get_parameter("publish_tf").as_bool();
    joint_sub_ = create_subscription<sensor_msgs::msg::JointState>(
        "/joint_states", 10, std::bind(&NoisyController::jointCallback, this, _1));
    odom_pub_ = create_publisher<nav_msgs::msg::Odometry>("/rover_controller/odom_noisy", 10);
    odom_msg_.header.frame_id = "odom";
    odom_msg_.child_frame_id = "base_footprint_ekf";
    odom_msg_.pose.pose.orientation.w = 1.0;
    transform_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
    transform_stamped_.header.frame_id = "odom";
    transform_stamped_.child_frame_id = "base_footprint_ekf";
}

void NoisyController::jointCallback(const sensor_msgs::msg::JointState &state)
{
    const auto left_it = std::find(state.name.begin(), state.name.end(), "left_encoder_joint");
    const auto right_it = std::find(state.name.begin(), state.name.end(), "right_encoder_joint");
    if (left_it == state.name.end() || right_it == state.name.end()) {
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 3000, "Encoder joints missing; skipping noisy odometry");
        return;
    }
    const auto li = static_cast<std::size_t>(std::distance(state.name.begin(), left_it));
    const auto ri = static_cast<std::size_t>(std::distance(state.name.begin(), right_it));
    if (li >= state.position.size() || ri >= state.position.size()) return;

    // This node is a simulation/noise helper. Keep noise isolated from the actual hardware path.
    static std::default_random_engine generator(
        static_cast<unsigned>(std::chrono::steady_clock::now().time_since_epoch().count()));
    static std::normal_distribution<double> noise(0.0, 0.005);
    const double left_pos = state.position[li] + noise(generator);
    const double right_pos = state.position[ri] + noise(generator);
    const rclcpp::Time msg_time(state.header.stamp);
    if (first_measurement_) {
        left_wheel_prev_pos_ = left_pos;
        right_wheel_prev_pos_ = right_pos;
        prev_time_ = msg_time;
        first_measurement_ = false;
        return;
    }
    const double dt = (msg_time - prev_time_).seconds();
    if (!std::isfinite(dt) || dt <= 0.0) {
        left_wheel_prev_pos_ = left_pos; right_wheel_prev_pos_ = right_pos; prev_time_ = msg_time;
        return;
    }
    const double dp_left = left_pos - left_wheel_prev_pos_;
    const double dp_right = right_pos - right_wheel_prev_pos_;
    left_wheel_prev_pos_ = left_pos; right_wheel_prev_pos_ = right_pos; prev_time_ = msg_time;
    const double fi_left = dp_left / dt;
    const double fi_right = dp_right / dt;
    const double linear = wheel_radius_ * (fi_right + fi_left) / 2.0;
    const double angular = wheel_radius_ * (fi_right - fi_left) / wheel_separation_;
    const double ds = wheel_radius_ * (dp_right + dp_left) / 2.0;
    const double dtheta = wheel_radius_ * (dp_right - dp_left) / wheel_separation_;
    theta_ += dtheta; x_ += ds * std::cos(theta_); y_ += ds * std::sin(theta_);
    tf2::Quaternion q; q.setRPY(0.0, 0.0, theta_);
    const auto stamp = get_clock()->now();
    odom_msg_.header.stamp = stamp;
    odom_msg_.pose.pose.position.x = x_; odom_msg_.pose.pose.position.y = y_;
    odom_msg_.pose.pose.orientation.x = q.x(); odom_msg_.pose.pose.orientation.y = q.y();
    odom_msg_.pose.pose.orientation.z = q.z(); odom_msg_.pose.pose.orientation.w = q.w();
    odom_msg_.twist.twist.linear.x = linear; odom_msg_.twist.twist.angular.z = angular;
    odom_pub_->publish(odom_msg_);
    if (publish_tf_) {
        transform_stamped_.header.stamp = stamp;
        transform_stamped_.transform.translation.x = x_; transform_stamped_.transform.translation.y = y_;
        transform_stamped_.transform.translation.z = 0.0;
        transform_stamped_.transform.rotation.x = q.x(); transform_stamped_.transform.rotation.y = q.y();
        transform_stamped_.transform.rotation.z = q.z(); transform_stamped_.transform.rotation.w = q.w();
        transform_broadcaster_->sendTransform(transform_stamped_);
    }
}

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<NoisyController>("noisy_controller"));
    rclcpp::shutdown();
    return 0;
}
