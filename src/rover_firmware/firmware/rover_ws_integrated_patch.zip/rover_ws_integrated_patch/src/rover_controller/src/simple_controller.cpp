#include "rover_controller/simple_controller.hpp"

#include <Eigen/Geometry>
#include <tf2/LinearMath/Quaternion.h>
#include <algorithm>
#include <cmath>
#include <iterator>
#include <string>
#include <stdexcept>

using std::placeholders::_1;

SimpleController::SimpleController(const std::string& name)
  : Node(name), prev_time_(get_clock()->now())
{
    declare_parameter("wheel_radius", 0.1);
    declare_parameter("wheel_separation", 0.5767);
    declare_parameter("publish_tf", true);
    wheel_radius_ = get_parameter("wheel_radius").as_double();
    wheel_separation_ = get_parameter("wheel_separation").as_double();
    publish_tf_ = get_parameter("publish_tf").as_bool();

    if (wheel_radius_ <= 0.0 || wheel_separation_ <= 0.0) {
        throw std::invalid_argument("wheel_radius and wheel_separation must be positive");
    }
    RCLCPP_INFO(get_logger(), "Wheel radius %.4f, separation %.4f, publish_tf=%s",
                wheel_radius_, wheel_separation_, publish_tf_ ? "true" : "false");

    wheel_cmd_pub_ = create_publisher<std_msgs::msg::Float64MultiArray>(
        "/simple_velocity_controller/commands", 10);
    vel_sub_ = create_subscription<geometry_msgs::msg::TwistStamped>(
        "/rover_controller/cmd_vel", 10, std::bind(&SimpleController::velCallback, this, _1));
    joint_sub_ = create_subscription<sensor_msgs::msg::JointState>(
        "/joint_states", 10, std::bind(&SimpleController::jointCallback, this, _1));
    odom_pub_ = create_publisher<nav_msgs::msg::Odometry>("/rover_controller/odom", 10);

    speed_conversion_ << wheel_radius_/2.0, wheel_radius_/2.0,
                         wheel_radius_/wheel_separation_, -wheel_radius_/wheel_separation_;

    odom_msg_.header.frame_id = "odom";
    odom_msg_.child_frame_id = "base_footprint";
    odom_msg_.pose.pose.orientation.w = 1.0;
    transform_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
    transform_stamped_.header.frame_id = "odom";
    transform_stamped_.child_frame_id = "base_footprint";
}

void SimpleController::velCallback(const geometry_msgs::msg::TwistStamped &msg)
{
    Eigen::Vector2d robot_speed(msg.twist.linear.x, msg.twist.angular.z);
    Eigen::Vector2d wheel_speed = speed_conversion_.inverse() * robot_speed;
    const double left_speed = wheel_speed.coeff(1);
    const double right_speed = wheel_speed.coeff(0);

    // Must match simple_velocity_controller.joints exactly:
    // left wheel, left encoder, right wheel, right encoder.
    std_msgs::msg::Float64MultiArray command;
    command.data = {left_speed, left_speed, right_speed, right_speed};
    wheel_cmd_pub_->publish(command);
}

void SimpleController::jointCallback(const sensor_msgs::msg::JointState &state)
{
    const auto left_it = std::find(state.name.begin(), state.name.end(), "left_encoder_joint");
    const auto right_it = std::find(state.name.begin(), state.name.end(), "right_encoder_joint");
    if (left_it == state.name.end() || right_it == state.name.end()) {
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 3000,
            "Encoder joints missing from /joint_states; skipping odometry update");
        return;
    }
    const auto left_idx = static_cast<std::size_t>(std::distance(state.name.begin(), left_it));
    const auto right_idx = static_cast<std::size_t>(std::distance(state.name.begin(), right_it));
    if (left_idx >= state.position.size() || right_idx >= state.position.size()) {
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 3000,
            "Encoder positions missing from /joint_states; skipping odometry update");
        return;
    }

    const double left_position = state.position[left_idx];
    const double right_position = state.position[right_idx];
    const rclcpp::Time msg_time(state.header.stamp);
    if (is_first_callback_) {
        left_wheel_prev_pos_ = left_position;
        right_wheel_prev_pos_ = right_position;
        prev_time_ = msg_time;
        is_first_callback_ = false;
        return;
    }

    const double dt = (msg_time - prev_time_).seconds();
    // Always refresh baselines when timestamps are duplicate/backwards; never divide by zero.
    if (!std::isfinite(dt) || dt <= 0.0) {
        left_wheel_prev_pos_ = left_position;
        right_wheel_prev_pos_ = right_position;
        prev_time_ = msg_time;
        return;
    }

    const double dp_left = left_position - left_wheel_prev_pos_;
    const double dp_right = right_position - right_wheel_prev_pos_;
    left_wheel_prev_pos_ = left_position;
    right_wheel_prev_pos_ = right_position;
    prev_time_ = msg_time;

    const double left_speed = dp_left / dt;
    const double right_speed = dp_right / dt;
    const double linear = wheel_radius_ * (right_speed + left_speed) / 2.0;
    const double angular = wheel_radius_ * (right_speed - left_speed) / wheel_separation_;
    const double d_s = wheel_radius_ * (dp_right + dp_left) / 2.0;
    const double d_theta = wheel_radius_ * (dp_right - dp_left) / wheel_separation_;
    theta_ += d_theta;
    x_ += d_s * std::cos(theta_);
    y_ += d_s * std::sin(theta_);

    tf2::Quaternion q;
    q.setRPY(0.0, 0.0, theta_);
    const auto stamp = get_clock()->now();
    odom_msg_.header.stamp = stamp;
    odom_msg_.pose.pose.position.x = x_;
    odom_msg_.pose.pose.position.y = y_;
    odom_msg_.pose.pose.orientation.x = q.x();
    odom_msg_.pose.pose.orientation.y = q.y();
    odom_msg_.pose.pose.orientation.z = q.z();
    odom_msg_.pose.pose.orientation.w = q.w();
    odom_msg_.twist.twist.linear.x = linear;
    odom_msg_.twist.twist.angular.z = angular;
    odom_pub_->publish(odom_msg_);

    if (publish_tf_) {
        transform_stamped_.header.stamp = stamp;
        transform_stamped_.transform.translation.x = x_;
        transform_stamped_.transform.translation.y = y_;
        transform_stamped_.transform.translation.z = 0.0;
        transform_stamped_.transform.rotation.x = q.x();
        transform_stamped_.transform.rotation.y = q.y();
        transform_stamped_.transform.rotation.z = q.z();
        transform_stamped_.transform.rotation.w = q.w();
        transform_broadcaster_->sendTransform(transform_stamped_);
    }
}

int main(int argc, char* argv[])
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SimpleController>("simple_controller"));
    rclcpp::shutdown();
    return 0;
}
