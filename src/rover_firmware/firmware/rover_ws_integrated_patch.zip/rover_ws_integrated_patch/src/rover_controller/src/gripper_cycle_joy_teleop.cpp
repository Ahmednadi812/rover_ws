#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joy.hpp"
#include "std_msgs/msg/bool.hpp"

#include <cstddef>
#include <cstdio>
#include <cstdint>
#include <memory>
#include <stdexcept>

class GripperCycleJoyTeleop final : public rclcpp::Node
{
public:
  GripperCycleJoyTeleop() : Node("gripper_cycle_joy_teleop")
  {
    declare_parameter<int64_t>("cycle_button_index", 0);
    cycle_button_index_ = get_parameter("cycle_button_index").as_int();
    if (cycle_button_index_ < 0) {
      throw std::invalid_argument("cycle_button_index must be >= 0");
    }
    request_pub_ = create_publisher<std_msgs::msg::Bool>("/gripper/cycle_request", 10);
    joy_sub_ = create_subscription<sensor_msgs::msg::Joy>(
      "/joy", rclcpp::QoS(10),
      [this](const sensor_msgs::msg::Joy::SharedPtr msg) {
        const auto index = static_cast<std::size_t>(cycle_button_index_);
        if (index >= msg->buttons.size()) {
          // Joystick drivers sometimes publish shorter arrays; never index out of bounds.
          return;
        }
        const bool pressed = msg->buttons[index] != 0;
        if (pressed && !previous_pressed_) {
          std_msgs::msg::Bool request;
          request.data = true;
          request_pub_->publish(request);
          RCLCPP_INFO(get_logger(), "One-shot gripper cycle request (button %lld)", static_cast<long long>(cycle_button_index_));
        }
        previous_pressed_ = pressed;
      });
    RCLCPP_INFO(get_logger(), "Gripper cycle button index: %lld", static_cast<long long>(cycle_button_index_));
  }

private:
  int64_t cycle_button_index_{0};
  bool previous_pressed_{false};
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr request_pub_;
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr joy_sub_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  try {
    rclcpp::spin(std::make_shared<GripperCycleJoyTeleop>());
  } catch (const std::exception & ex) {
    fprintf(stderr, "gripper_cycle_joy_teleop: %s\n", ex.what());
    rclcpp::shutdown();
    return 1;
  }
  rclcpp::shutdown();
  return 0;
}
