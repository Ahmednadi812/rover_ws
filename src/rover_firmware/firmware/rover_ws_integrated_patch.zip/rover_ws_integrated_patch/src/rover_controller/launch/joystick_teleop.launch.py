import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    rover_controller_pkg = get_package_share_directory('rover_controller')

    use_sim_time_arg = DeclareLaunchArgument(
        name="use_sim_time", default_value="True", description="Use simulated time")
    cycle_button_arg = DeclareLaunchArgument(
        name="cycle_button_index", default_value="0",
        description="Joystick button index that requests one complete gripper cycle (inspect /joy first)")

    joy_teleop = Node(
        package="joy_teleop", executable="joy_teleop",
        parameters=[os.path.join(rover_controller_pkg, "config", "joy_teleop.yaml"),
                    {"use_sim_time": LaunchConfiguration("use_sim_time")}])

    joy_node = Node(
        package="joy", executable="joy_node", name="joystick",
        parameters=[os.path.join(rover_controller_pkg, "config", "joy_config.yaml"),
                    {"use_sim_time": LaunchConfiguration("use_sim_time")}])

    gripper_joy_teleop = Node(
        package="rover_controller", executable="gripper_joy_teleop",
        parameters=[{"open_button_index": 2}, {"close_button_index": 3},
                    {"use_sim_time": LaunchConfiguration("use_sim_time")}])

    gripper_cycle_joy_teleop = Node(
        package="rover_controller", executable="gripper_cycle_joy_teleop",
        parameters=[{"cycle_button_index": ParameterValue(LaunchConfiguration("cycle_button_index"), value_type=int)},
                    {"use_sim_time": LaunchConfiguration("use_sim_time")}])

    twist_mux_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory("twist_mux"), "launch", "twist_mux_launch.py")),
        launch_arguments={
            "cmd_vel_out": "rover_controller/cmd_vel_unstamped",
            "config_locks": os.path.join(rover_controller_pkg, "config", "twist_mux_locks.yaml"),
            "config_topics": os.path.join(rover_controller_pkg, "config", "twist_mux_topics.yaml"),
            "config_joy": os.path.join(rover_controller_pkg, "config", "twist_mux_joy.yaml"),
            "use_sim_time": LaunchConfiguration("use_sim_time"),
        }.items())

    twist_relay_node = Node(
        package="rover_controller", executable="twist_relay", name="twist_relay",
        parameters=[{"use_sim_time": LaunchConfiguration("use_sim_time")}])

    return LaunchDescription([
        use_sim_time_arg, cycle_button_arg, joy_teleop, joy_node,
        twist_mux_launch, twist_relay_node, gripper_joy_teleop,
        gripper_cycle_joy_teleop,
    ])
