from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, OpaqueFunction
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.conditions import UnlessCondition, IfCondition


def noisy_controller(context, *args, **kwargs):
    enabled = LaunchConfiguration("use_noisy_controller").perform(context).lower() in ("true", "1", "yes")
    if not enabled:
        return []
    use_sim_time = LaunchConfiguration("use_sim_time")
    use_python = LaunchConfiguration("use_python")
    wheel_radius = float(LaunchConfiguration("wheel_radius").perform(context))
    wheel_separation = float(LaunchConfiguration("wheel_separation").perform(context))
    wheel_radius_error = float(LaunchConfiguration("wheel_radius_error").perform(context))
    wheel_separation_error = float(LaunchConfiguration("wheel_separation_error").perform(context))
    common_params = {
        "wheel_radius": wheel_radius + wheel_radius_error,
        "wheel_separation": wheel_separation + wheel_separation_error,
        "use_sim_time": use_sim_time,
        "publish_tf": LaunchConfiguration("publish_noisy_tf"),
    }
    return [
        Node(package="rover_controller", executable="noisy_controller.py", parameters=[common_params], condition=IfCondition(use_python)),
        Node(package="rover_controller", executable="noisy_controller", parameters=[common_params], condition=UnlessCondition(use_python)),
    ]


def generate_launch_description():
    use_sim_time_arg = DeclareLaunchArgument("use_sim_time", default_value="True")
    use_simple_controller_arg = DeclareLaunchArgument("use_simple_controller", default_value="True")
    use_python_arg = DeclareLaunchArgument("use_python", default_value="False")
    use_noisy_controller_arg = DeclareLaunchArgument(
        "use_noisy_controller", default_value="True",
        description="Start the extra noisy odometry estimator (normally simulation-only)")
    publish_simple_tf_arg = DeclareLaunchArgument(
        "publish_simple_tf", default_value="True",
        description="Let simple_controller publish odom->base_footprint TF")
    publish_noisy_tf_arg = DeclareLaunchArgument(
        "publish_noisy_tf", default_value="False",
        description="Let noisy_controller publish odom->base_footprint_ekf TF")
    wheel_radius_arg = DeclareLaunchArgument("wheel_radius", default_value="0.1")
    wheel_separation_arg = DeclareLaunchArgument("wheel_separation", default_value="0.5767")
    wheel_radius_error_arg = DeclareLaunchArgument("wheel_radius_error", default_value="0.005")
    wheel_separation_error_arg = DeclareLaunchArgument("wheel_separation_error", default_value="0.02")

    use_sim_time = LaunchConfiguration("use_sim_time")
    use_simple_controller = LaunchConfiguration("use_simple_controller")
    use_python = LaunchConfiguration("use_python")
    wheel_radius = LaunchConfiguration("wheel_radius")
    wheel_separation = LaunchConfiguration("wheel_separation")

    joint_state_broadcaster_spawner = Node(
        package="controller_manager", executable="spawner",
        arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"])
    wheel_controller_spawner = Node(
        package="controller_manager", executable="spawner",
        arguments=["rover_controller", "--controller-manager", "/controller_manager"],
        condition=UnlessCondition(use_simple_controller))
    gripper_controller_spawner = Node(
        package="controller_manager", executable="spawner",
        arguments=["gripper_controller", "--controller-manager", "/controller_manager"])

    simple_controller = GroupAction(condition=IfCondition(use_simple_controller), actions=[
        Node(package="controller_manager", executable="spawner",
             arguments=["simple_velocity_controller", "--controller-manager", "/controller_manager"]),
        Node(package="rover_controller", executable="simple_controller.py",
             parameters=[{"wheel_radius": wheel_radius, "wheel_separation": wheel_separation,
                          "use_sim_time": use_sim_time, "publish_tf": LaunchConfiguration("publish_simple_tf")}],
             condition=IfCondition(use_python)),
        Node(package="rover_controller", executable="simple_controller",
             parameters=[{"wheel_radius": wheel_radius, "wheel_separation": wheel_separation,
                          "use_sim_time": use_sim_time, "publish_tf": LaunchConfiguration("publish_simple_tf")}],
             condition=UnlessCondition(use_python)),
    ])
    noisy_controller_launch = OpaqueFunction(function=noisy_controller)
    return LaunchDescription([
        use_sim_time_arg, use_simple_controller_arg, use_python_arg,
        use_noisy_controller_arg, publish_simple_tf_arg, publish_noisy_tf_arg,
        wheel_radius_arg, wheel_separation_arg, wheel_radius_error_arg, wheel_separation_error_arg,
        joint_state_broadcaster_spawner, wheel_controller_spawner, simple_controller,
        noisy_controller_launch, gripper_controller_spawner,
    ])
