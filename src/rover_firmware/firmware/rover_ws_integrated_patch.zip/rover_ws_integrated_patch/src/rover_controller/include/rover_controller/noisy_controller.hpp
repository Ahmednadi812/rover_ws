#ifndef NOISY_CONTROLLER_HPP
#define NOISY_CONTROLLER_HPP
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <tf2_ros/transform_broadcaster.h>
class NoisyController : public rclcpp::Node {
public: NoisyController(const std::string& name);
private:
 void jointCallback(const sensor_msgs::msg::JointState &msg);
 rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr joint_sub_;
 rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr odom_pub_;
 double wheel_radius_{0.105}; double wheel_separation_{0.5967};
 double right_wheel_prev_pos_{0.0}; double left_wheel_prev_pos_{0.0};
 rclcpp::Time prev_time_; nav_msgs::msg::Odometry odom_msg_;
 double x_{0.0}; double y_{0.0}; double theta_{0.0}; bool first_measurement_{true}; bool publish_tf_{false};
 std::unique_ptr<tf2_ros::TransformBroadcaster> transform_broadcaster_;
 geometry_msgs::msg::TransformStamped transform_stamped_;
};
#endif
