#!/usr/bin/env python3
import math
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from sensor_msgs.msg import JointState
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf2_ros import TransformBroadcaster
from tf_transformations import quaternion_from_euler

class NoisyController(Node):
    def __init__(self):
        super().__init__("noisy_controller")
        self.declare_parameter("wheel_radius", 0.105)
        self.declare_parameter("wheel_separation", 0.5967)
        self.declare_parameter("publish_tf", False)
        self.wheel_radius_ = float(self.get_parameter("wheel_radius").value)
        self.wheel_separation_ = float(self.get_parameter("wheel_separation").value)
        self.publish_tf_ = bool(self.get_parameter("publish_tf").value)
        self.left_prev_ = 0.0
        self.right_prev_ = 0.0
        self.first_ = True
        self.x_ = self.y_ = self.theta_ = 0.0
        self.prev_time_ = self.get_clock().now()
        self.odom_msg_ = Odometry()
        self.odom_msg_.header.frame_id = "odom"
        self.odom_msg_.child_frame_id = "base_footprint_ekf"
        self.odom_msg_.pose.pose.orientation.w = 1.0
        self.odom_pub_ = self.create_publisher(Odometry, "/rover_controller/odom_noisy", 10)
        self.sub_ = self.create_subscription(JointState, "/joint_states", self.joint_callback, 10)
        self.br_ = TransformBroadcaster(self)
        self.tf_ = TransformStamped()
        self.tf_.header.frame_id = "odom"
        self.tf_.child_frame_id = "base_footprint_ekf"
        self.rng_ = np.random.default_rng()

    def joint_callback(self, state):
        try:
            li = state.name.index("left_encoder_joint")
            ri = state.name.index("right_encoder_joint")
        except ValueError:
            self.get_logger().warning("Encoder joints missing; skipping noisy odometry", throttle_duration_sec=3.0)
            return
        if li >= len(state.position) or ri >= len(state.position) or self.wheel_radius_ <= 0 or self.wheel_separation_ <= 0:
            return
        left = float(state.position[li]) + float(self.rng_.normal(0.0, 0.005))
        right = float(state.position[ri]) + float(self.rng_.normal(0.0, 0.005))
        stamp = Time.from_msg(state.header.stamp)
        if self.first_:
            self.left_prev_, self.right_prev_, self.prev_time_ = left, right, stamp
            self.first_ = False
            return
        dt = (stamp - self.prev_time_).nanoseconds / 1e9
        if not math.isfinite(dt) or dt <= 0.0:
            self.left_prev_, self.right_prev_, self.prev_time_ = left, right, stamp
            return
        dl, dr = left - self.left_prev_, right - self.right_prev_
        self.left_prev_, self.right_prev_, self.prev_time_ = left, right, stamp
        vl, vr = dl / dt, dr / dt
        linear = self.wheel_radius_ * (vr + vl) / 2.0
        angular = self.wheel_radius_ * (vr - vl) / self.wheel_separation_
        ds = self.wheel_radius_ * (dr + dl) / 2.0
        dtheta = self.wheel_radius_ * (dr - dl) / self.wheel_separation_
        self.theta_ += dtheta
        self.x_ += ds * math.cos(self.theta_)
        self.y_ += ds * math.sin(self.theta_)
        q = quaternion_from_euler(0.0, 0.0, self.theta_)
        now = self.get_clock().now().to_msg()
        self.odom_msg_.header.stamp = now
        self.odom_msg_.pose.pose.position.x = self.x_
        self.odom_msg_.pose.pose.position.y = self.y_
        self.odom_msg_.pose.pose.orientation.x, self.odom_msg_.pose.pose.orientation.y = q[0], q[1]
        self.odom_msg_.pose.pose.orientation.z, self.odom_msg_.pose.pose.orientation.w = q[2], q[3]
        self.odom_msg_.twist.twist.linear.x = linear
        self.odom_msg_.twist.twist.angular.z = angular
        self.odom_pub_.publish(self.odom_msg_)
        if self.publish_tf_:
            self.tf_.header.stamp = now
            self.tf_.transform.translation.x, self.tf_.transform.translation.y = self.x_, self.y_
            self.tf_.transform.rotation.x, self.tf_.transform.rotation.y = q[0], q[1]
            self.tf_.transform.rotation.z, self.tf_.transform.rotation.w = q[2], q[3]
            self.br_.sendTransform(self.tf_)

def main(args=None):
    rclpy.init(args=args)
    node = NoisyController()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
