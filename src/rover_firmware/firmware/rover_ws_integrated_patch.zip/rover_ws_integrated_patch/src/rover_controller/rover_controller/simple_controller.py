#!/usr/bin/env python3
import math
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from std_msgs.msg import Float64MultiArray
from geometry_msgs.msg import TwistStamped, TransformStamped
from sensor_msgs.msg import JointState
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from tf_transformations import quaternion_from_euler

class SimpleController(Node):
    def __init__(self):
        super().__init__("simple_controller")
        self.declare_parameter("wheel_radius", 0.1)
        self.declare_parameter("wheel_separation", 0.5767)
        self.declare_parameter("publish_tf", True)
        self.wheel_radius_ = float(self.get_parameter("wheel_radius").value)
        self.wheel_separation_ = float(self.get_parameter("wheel_separation").value)
        self.publish_tf_ = bool(self.get_parameter("publish_tf").value)
        if self.wheel_radius_ <= 0.0 or self.wheel_separation_ <= 0.0:
            raise ValueError("wheel_radius and wheel_separation must be positive")

        self.left_wheel_prev_pos_ = 0.0
        self.right_wheel_prev_pos_ = 0.0
        self.x_ = self.y_ = self.theta_ = 0.0
        self.is_first_callback_ = True
        self.speed_conversion_ = np.array([
            [self.wheel_radius_ / 2.0, self.wheel_radius_ / 2.0],
            [self.wheel_radius_ / self.wheel_separation_, -self.wheel_radius_ / self.wheel_separation_],
        ])
        self.wheel_cmd_pub_ = self.create_publisher(Float64MultiArray, "/simple_velocity_controller/commands", 10)
        self.vel_sub_ = self.create_subscription(TwistStamped, "/rover_controller/cmd_vel", self.velCallback, 10)
        self.joint_sub_ = self.create_subscription(JointState, "/joint_states", self.jointCallback, 10)
        self.odom_pub_ = self.create_publisher(Odometry, "/rover_controller/odom", 10)

        self.odom_msg_ = Odometry()
        self.odom_msg_.header.frame_id = "odom"
        self.odom_msg_.child_frame_id = "base_footprint"
        self.odom_msg_.pose.pose.orientation.w = 1.0
        self.br_ = TransformBroadcaster(self)
        self.transform_stamped_ = TransformStamped()
        self.transform_stamped_.header.frame_id = "odom"
        self.transform_stamped_.child_frame_id = "base_footprint"
        self.prev_time_ = self.get_clock().now()
        self.get_logger().info(f"simple_controller publish_tf={self.publish_tf_}")

    def velCallback(self, msg):
        robot_speed = np.array([[msg.twist.linear.x], [msg.twist.angular.z]])
        wheel_speed = np.linalg.inv(self.speed_conversion_) @ robot_speed
        left_speed = float(wheel_speed[1, 0])
        right_speed = float(wheel_speed[0, 0])
        command = Float64MultiArray()
        command.data = [left_speed, left_speed, right_speed, right_speed]
        self.wheel_cmd_pub_.publish(command)

    def jointCallback(self, msg):
        try:
            left_idx = msg.name.index("left_encoder_joint")
            right_idx = msg.name.index("right_encoder_joint")
        except ValueError:
            self.get_logger().warning("Encoder joints missing from /joint_states", throttle_duration_sec=3.0)
            return
        if left_idx >= len(msg.position) or right_idx >= len(msg.position):
            self.get_logger().warning("Encoder positions missing from /joint_states", throttle_duration_sec=3.0)
            return

        left_pos = float(msg.position[left_idx])
        right_pos = float(msg.position[right_idx])
        msg_time = Time.from_msg(msg.header.stamp)
        if self.is_first_callback_:
            self.left_wheel_prev_pos_ = left_pos
            self.right_wheel_prev_pos_ = right_pos
            self.prev_time_ = msg_time
            self.is_first_callback_ = False
            return
        dt = (msg_time - self.prev_time_).nanoseconds / 1e9
        if not math.isfinite(dt) or dt <= 0.0:
            self.left_wheel_prev_pos_ = left_pos
            self.right_wheel_prev_pos_ = right_pos
            self.prev_time_ = msg_time
            return

        dp_left = left_pos - self.left_wheel_prev_pos_
        dp_right = right_pos - self.right_wheel_prev_pos_
        self.left_wheel_prev_pos_ = left_pos
        self.right_wheel_prev_pos_ = right_pos
        self.prev_time_ = msg_time

        fi_left = dp_left / dt
        fi_right = dp_right / dt
        linear = self.wheel_radius_ * (fi_right + fi_left) / 2.0
        angular = self.wheel_radius_ * (fi_right - fi_left) / self.wheel_separation_
        ds = self.wheel_radius_ * (dp_right + dp_left) / 2.0
        dtheta = self.wheel_radius_ * (dp_right - dp_left) / self.wheel_separation_
        self.theta_ += dtheta
        self.x_ += ds * math.cos(self.theta_)
        self.y_ += ds * math.sin(self.theta_)

        q = quaternion_from_euler(0.0, 0.0, self.theta_)
        stamp = self.get_clock().now().to_msg()
        self.odom_msg_.header.stamp = stamp
        self.odom_msg_.pose.pose.position.x = self.x_
        self.odom_msg_.pose.pose.position.y = self.y_
        self.odom_msg_.pose.pose.orientation.x = q[0]
        self.odom_msg_.pose.pose.orientation.y = q[1]
        self.odom_msg_.pose.pose.orientation.z = q[2]
        self.odom_msg_.pose.pose.orientation.w = q[3]
        self.odom_msg_.twist.twist.linear.x = linear
        self.odom_msg_.twist.twist.angular.z = angular
        self.odom_pub_.publish(self.odom_msg_)

        if self.publish_tf_:
            self.transform_stamped_.header.stamp = stamp
            self.transform_stamped_.transform.translation.x = self.x_
            self.transform_stamped_.transform.translation.y = self.y_
            self.transform_stamped_.transform.translation.z = 0.0
            self.transform_stamped_.transform.rotation.x = q[0]
            self.transform_stamped_.transform.rotation.y = q[1]
            self.transform_stamped_.transform.rotation.z = q[2]
            self.transform_stamped_.transform.rotation.w = q[3]
            self.br_.sendTransform(self.transform_stamped_)

def main():
    rclpy.init()
    node = SimpleController()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
