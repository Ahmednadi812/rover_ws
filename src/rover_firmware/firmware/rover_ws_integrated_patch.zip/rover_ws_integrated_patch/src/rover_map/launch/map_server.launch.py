import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    package_name = 'rover_map'
    package_share = get_package_share_directory(package_name)
    map_path = os.path.join(package_share, 'maps', 'map.pgm')
    map_file = os.path.join(package_share, 'maps', 'map.yaml')

    # Save the annotated image alongside the installed/source map instead of
    # hard-coding one developer's /home/nadi workspace path.
    output_map_path = os.path.expanduser('~/.ros/annotated_map.png')
    os.makedirs(os.path.dirname(output_map_path), exist_ok=True)

    map_set = Node(
        package="rover_map",
        executable="annotated_map_publisher",
        parameters=[{
            'input_map_path': map_path,
            'output_map_path': output_map_path,
            'resolution': 0.025,
            'origin_x': -0.5,
            'origin_y': -0.5,
        }],
    )

    map_server = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[{'yaml_filename': map_file}],
    )

    lifecycle_manager = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_map',
        output='screen',
        parameters=[{'autostart': True, 'node_names': ['map_server']}],
    )
    set_pos_map = Node(package="rover_map", executable="set_init_pos")

    # REP-105 hierarchy: map is the parent of odom. This is an identity
    # initial alignment for the current static-map setup, not a substitute for
    # a global-localization system that estimates a changing map -> odom TF.
    static_map_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_map_tf',
        arguments=[
            '--x', '0', '--y', '0', '--z', '0',
            '--yaw', '0', '--pitch', '0', '--roll', '0',
            '--frame-id', 'map', '--child-frame-id', 'odom',
        ],
    )

    return LaunchDescription([
        map_server,
        lifecycle_manager,
        set_pos_map,
        static_map_tf,
        map_set,
    ])
