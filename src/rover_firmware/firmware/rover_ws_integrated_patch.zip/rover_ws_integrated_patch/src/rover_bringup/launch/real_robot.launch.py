import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    hardware_interface = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rover_firmware"),
                                                   "launch", "hardware_interface.launch.py")))
    controller = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rover_controller"),
                                                   "launch", "controller.launch.py")),
        launch_arguments={
            "use_simple_controller": "true",
            "use_python": "False",
            "use_sim_time": "False",
            "use_noisy_controller": "False",
            "publish_simple_tf": "False",
            "publish_noisy_tf": "False",
        }.items())
    joystick = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rover_controller"),
                                                   "launch", "joystick_teleop.launch.py")),
        launch_arguments={"use_sim_time": "False"}.items())
    zigzag = Node(
        package="rover_planning", executable="zigzag_planner", name="zigzag_planner", output="screen",
        parameters=[{"use_sim_time": False, "base_frame": "base_footprint_ekf",
                     "margin": 2.0, "lane_spacing": 1.0, "point_step": 0.1, "lanes_along_x": True}])
    map_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rover_map"),
                                                   "launch", "map_server.launch.py")))
    localization = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(get_package_share_directory("rover_localization"),
                                                   "launch", "local_localization.launch.py")),
        launch_arguments={"use_sim_time": "False", "use_python": "False",
                          "odom_topic": "rover_controller/odom"}.items())
    # The EKF input requires /imu/out. Keep the hardware driver's existing enable/launch policy;
    # verify the topic exists before this launch, or disable imu0 in ekf.yaml when no IMU is available.
    return LaunchDescription([hardware_interface, controller, joystick, zigzag, map_launch, localization])
