#!/usr/bin/env python3
"""Mine grid visualization accepting vision-cell and hardware sensor topics.

Cell association is time-limited. A sustained high sensor level creates one map
record per rising edge. Metal detections take precedence over proximity detections
on a cell; the dictionary ensures repeated detections never make duplicate cells.
"""
import time
import cv2 as cv
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, String


class MapNode(Node):
    def __init__(self):
        super().__init__("map_node")
        self.declare_parameter("cell_freshness_sec", 1.0)
        self.cell_freshness_sec = max(0.1, float(self.get_parameter("cell_freshness_sec").value))
        self.cell_by_source = {"vision": ("", 0.0), "legacy": ("", 0.0)}
        self.mines = {}  # cell -> {type, monotonic_time}; one entry per cell
        self.proximity_active = False
        self.metal_active = False

        self.create_subscription(
            String, "/vision_cell", lambda msg: self.cell_callback(msg, "vision"), 10)
        # Backward compatibility for configurations that still publish /current_cell.
        self.create_subscription(
            String, "/current_cell", lambda msg: self.cell_callback(msg, "legacy"), 10)
        self.create_subscription(String, "/mine_type", self.type_callback, 10)
        self.create_subscription(Bool, "/proximity", self.proximity_callback, 10)
        self.create_subscription(Bool, "/metal_detector", self.metal_callback, 10)

        cv.namedWindow("Mine Map", cv.WINDOW_NORMAL)
        cv.resizeWindow("Mine Map", 900, 900)
        self.timer = self.create_timer(0.1, self.draw_map)
        self.get_logger().info(
            f"Map node started; cell freshness window={self.cell_freshness_sec:.2f}s")

    @staticmethod
    def valid_cell(cell):
        if not isinstance(cell, str) or len(cell) < 2:
            return False
        letter = cell[0].upper()
        number = cell[1:]
        return "A" <= letter <= "S" and number.isdigit() and 1 <= int(number) <= 19

    def cell_callback(self, msg, source):
        cell = msg.data.strip().upper()
        now = time.monotonic()
        # An empty/invalid update clears only that source; it never refreshes a
        # previously seen cell and cannot accidentally erase the other source.
        self.cell_by_source[source] = (cell if self.valid_cell(cell) else "", now)

    def current_fresh_cell(self):
        now = time.monotonic()
        fresh = [(cell, stamp) for cell, stamp in self.cell_by_source.values()
                 if cell and self.valid_cell(cell) and now - stamp <= self.cell_freshness_sec]
        if not fresh:
            return None
        return max(fresh, key=lambda entry: entry[1])[0]

    def mark_cell(self, cell, mine_type):
        if not self.valid_cell(cell):
            return
        now = time.monotonic()
        existing = self.mines.get(cell)
        # Direct sensor classes take priority over the legacy Surface/Buried label;
        # Metal outranks Proximity when both report the same grid cell.
        priority = {"Metal": 3, "Proximity": 2, "Surface": 1, "Buried": 1}
        if existing and priority.get(existing["type"], 0) > priority.get(mine_type, 0):
            return
        if existing and existing["type"] == mine_type:
            existing["time"] = now
            return
        self.mines[cell] = {"type": mine_type, "time": now}
        self.get_logger().info(f"Map updated: {cell} -> {mine_type}")

    def type_callback(self, msg):
        mine_type = msg.data.strip()
        if mine_type not in ("Surface", "Buried", "Proximity", "Metal"):
            return
        cell = self.current_fresh_cell()
        if cell:
            self.mark_cell(cell, mine_type)
        else:
            self.get_logger().warn("Mine type not mapped: no fresh valid vision cell")

    def proximity_callback(self, msg):
        active = bool(msg.data)
        rising = active and not self.proximity_active
        self.proximity_active = active
        if rising:
            cell = self.current_fresh_cell()
            if cell:
                self.mark_cell(cell, "Proximity")
            else:
                self.get_logger().warn("Proximity event not mapped: no fresh valid /vision_cell")

    def metal_callback(self, msg):
        active = bool(msg.data)
        rising = active and not self.metal_active
        self.metal_active = active
        if rising:
            cell = self.current_fresh_cell()
            if cell:
                self.mark_cell(cell, "Metal")
            else:
                self.get_logger().warn("Metal event not mapped: no fresh valid /vision_cell")

    def draw_map(self):
        cell_size = 40
        margin = 50
        bottom_margin = 90
        rows = cols = 19
        legend_width = 180
        width = cols * cell_size + margin * 2 + legend_width
        height = rows * cell_size + margin + bottom_margin
        img = np.ones((height, width, 3), dtype=np.uint8) * 255

        # Grid / labels.
        for r in range(rows + 1):
            y = margin + r * cell_size
            cv.line(img, (margin, y), (margin + cols * cell_size, y), (190, 190, 190), 1)
        for c in range(cols + 1):
            x = margin + c * cell_size
            cv.line(img, (x, margin), (x, margin + rows * cell_size), (190, 190, 190), 1)
        for number in range(1, 20):
            cv.putText(img, str(number), (10, margin + (rows - number) * cell_size + 25),
                       cv.FONT_HERSHEY_SIMPLEX, 0.6, (30, 30, 30), 2)
        for c in range(cols):
            cv.putText(img, chr(ord("A") + c), (margin + c * cell_size + 12,
                       margin + rows * cell_size + 30), cv.FONT_HERSHEY_SIMPLEX,
                       0.6, (30, 30, 30), 2)

        colors = {
            "Proximity": (0, 0, 255),  # red in OpenCV BGR
            "Metal": (0, 255, 0),      # green
            "Surface": (0, 255, 0),    # legacy compatibility
            "Buried": (19, 69, 139),   # legacy compatibility
        }
        for cell, record in self.mines.items():
            letter, number = cell[0], int(cell[1:])
            col = ord(letter) - ord("A")
            row = rows - number
            x1 = margin + col * cell_size + 1
            y1 = margin + row * cell_size + 1
            x2, y2 = x1 + cell_size - 2, y1 + cell_size - 2
            cv.rectangle(img, (x1, y1), (x2, y2), colors.get(record["type"], (128, 128, 128)), -1)
            label = record["type"][:1]
            cv.putText(img, label, (x1 + 13, y1 + 26), cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        legend_x = margin + cols * cell_size + 25
        legend = [("Proximity", colors["Proximity"]), ("Metal", colors["Metal"]),
                  ("Surface (legacy)", colors["Surface"]), ("Buried (legacy)", colors["Buried"])]
        cv.putText(img, "MINE MAP", (legend_x, 45), cv.FONT_HERSHEY_SIMPLEX, 0.7, (20, 20, 20), 2)
        for idx, (name, color) in enumerate(legend):
            y = 80 + idx * 42
            cv.rectangle(img, (legend_x, y), (legend_x + 23, y + 23), color, -1)
            cv.putText(img, name, (legend_x + 32, y + 18), cv.FONT_HERSHEY_SIMPLEX, 0.45, (20, 20, 20), 1)
        active_cell = self.current_fresh_cell()
        if active_cell:
            cv.putText(img, f"Current cell: {active_cell}", (legend_x, height - 28),
                       cv.FONT_HERSHEY_SIMPLEX, 0.5, (20, 20, 20), 1)
        cv.imshow("Mine Map", img)
        cv.waitKey(1)

    def destroy_node(self):
        cv.destroyAllWindows()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = MapNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
