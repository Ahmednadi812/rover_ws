#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu

class ImuRepublisher(Node):
    def __init__(self):
        super().__init__("imu_republisher_node")
        self.pub = self.create_publisher(Imu, "imu_ekf", 10)
        self.sub = self.create_subscription(Imu, "imu/out", self.callback, 10)
    def callback(self, msg):
        out = Imu()
        out.header = msg.header
        out.header.frame_id = "imu_link_ekf"
        out.orientation = msg.orientation
        out.orientation_covariance = msg.orientation_covariance
        out.angular_velocity = msg.angular_velocity
        out.angular_velocity_covariance = msg.angular_velocity_covariance
        out.linear_acceleration = msg.linear_acceleration
        out.linear_acceleration_covariance = msg.linear_acceleration_covariance
        self.pub.publish(out)

def main(args=None):
    rclpy.init(args=args)
    node = ImuRepublisher()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__": main()
